<?php

class Unirgy_Dropship_Block_Frontend_Vendor extends Mage_Core_Block_Template
{

}