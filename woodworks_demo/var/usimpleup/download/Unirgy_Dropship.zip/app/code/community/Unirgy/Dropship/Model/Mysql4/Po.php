<?php

class Unirgy_Dropship_Model_Mysql4_Po extends Mage_Sales_Model_Mysql4_Order_Shipment
{

}