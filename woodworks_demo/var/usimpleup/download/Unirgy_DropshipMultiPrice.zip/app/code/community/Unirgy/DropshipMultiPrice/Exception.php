<?php

class Unirgy_DropshipMultiPrice_Exception extends Mage_Core_Exception
{

}