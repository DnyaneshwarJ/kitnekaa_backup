<?php

class Unirgy_SimpleLicense_Model_License extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('usimplelic/license');
    }
}