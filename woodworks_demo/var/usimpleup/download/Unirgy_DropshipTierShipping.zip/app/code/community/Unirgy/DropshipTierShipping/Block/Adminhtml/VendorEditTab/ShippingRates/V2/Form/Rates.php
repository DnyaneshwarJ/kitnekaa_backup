<?php

class Unirgy_DropshipTierShipping_Block_Adminhtml_VendorEditTab_ShippingRates_V2_Form_Rates extends Varien_Data_Form_Element_Abstract
{
    public function getElementHtml()
    {
        return '<div id="'.$this->getHtmlId().'_container"></div>';
    }
}