<?php

class Unirgy_DropshipShippingClass_Block_Adminhtml_FormRenderer_ShipclassRows extends Mage_Adminhtml_Block_Widget implements Varien_Data_Form_Element_Renderer_Interface
{

    protected $_element = null;

    public function __construct()
    {
        $this->setTemplate('udshipclass/form_field/renderer/rows.phtml');
    }

    public function render(Varien_Data_Form_Element_Abstract $element)
    {
        $this->setElement($element);
        return $this->toHtml();
    }

    public function setElement(Varien_Data_Form_Element_Abstract $element)
    {
        $this->_element = $element;
        return $this;
    }

    public function getElement()
    {
        return $this->_element;
    }

    public function suffixId($id)
    {
        return $id.$this->getElement()->getId();
    }

}