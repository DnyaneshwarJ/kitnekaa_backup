<?php

class Unirgy_DropshipShippingClass_Model_Customer extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        $this->_init('udshipclass/customer');
    }
}
